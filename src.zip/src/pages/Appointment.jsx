import React from 'react'

const Appointment = () => {
  return (
    <div>
      
    </div>
  )
}

export default Appointment
